---
layout: default
title: Course Files
has_children: true
nav_order: 3
nav_exclude: False
---

# Course Files

[course-files/](.)

<table class="tbl-files">
    <tbody>
        <tr>
            <th valign="top"></th>
            <th>Name</th>
            <th>Last modified</th>
            <th>Size</th>
            <th>Preview</th>
        </tr>
        <tr>
            <td valign="top">
                <i class="fa fa-folder-open"></i>
            </td>
            <td><a href="../">Parent Directory</a></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>

        <tr>
            <td valign="top">
                <i class="fa fa-folder"></i>
            </td>
            <td><a href="administrative">administrative</a></td>
            <td align="right">3/3/2020 8:42 PM</td>
            <td>192.0B</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td valign="top">
                <i class="fa fa-folder"></i>
            </td>
            <td><a href="homework">homework</a></td>
            <td align="right">3/3/2020 8:42 PM</td>
            <td>512.0B</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td valign="top">
                <i class="fa fa-folder"></i>
            </td>
            <td><a href="lectures">lectures</a></td>
            <td align="right">3/5/2020 10:01 AM</td>
            <td>1.1KB</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td valign="top">
                <i class="fa fa-folder"></i>
            </td>
            <td><a href="practice_exams">practice_exams</a></td>
            <td align="right">3/1/2020 7:17 PM</td>
            <td>224.0B</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td valign="top">
                <i class="fa fa-folder"></i>
            </td>
            <td><a href="projects">projects</a></td>
            <td align="right">2/25/2020 8:57 AM</td>
            <td>224.0B</td>
            <td>&nbsp;</td>
        </tr>
    </tbody>
</table>

