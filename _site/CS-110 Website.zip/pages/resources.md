---
layout: page
title: Resources
permalink: /resources/
---

1. [Zoom](zoom/)
1. [Lockdown Browser](lockdown-browser/)
1. Alternative Code Editors:
  * [Visual Studio Code](visual-studio-code/)
  * [PyCharm](pycharm/)