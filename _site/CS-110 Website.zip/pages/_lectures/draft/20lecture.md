---
layout: module
title: Wrap Up & Exam 2 Review
type: review
draft: 1
num: 16
description: Fin
due_date: 2021-06-04

slides: 
   - title: "Practice Problems & Review"
     url: https://docs.google.com/presentation/d/1MH_ItyudXdWltbHBRi_2nPhm04spHe089ir5z--3AXo/edit?usp=sharing

exercise_url: "../practice_exams/exam02.zip"
---

A few notes on Exam 2:
* The exam will take place on Friday, 06/05, and will be cumulative. 
* I have posted 4 Practice Exams and a study guide in a <a href="https://drive.google.com/drive/folders/1isq6SB_kPZDZjQ3sDghyIPtBGxTjt6Ac?usp=sharing" target="_blank"> shared Google Drive folder <i class="fas fa-link"></i></a>. 
* You will be taking the exam using the Lockdown Browser.
* The best way to study for the exam is to do all of the practice exams and make sure you understand what each of the questions is asking you to do.
