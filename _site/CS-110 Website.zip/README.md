# Configuration and Installation
To run this course website locally, please install Jekyll and then do the following:

```bash
bundle install              # to install dependencies
bundle exec jekyll serve    # to run Jekyll from command line

# Then open link in a web browser:
# Server address: http://127.0.0.1:4000/spring2021/
```
