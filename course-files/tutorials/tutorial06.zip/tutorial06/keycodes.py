# Mac Key Codes
key_codes = {
    'mac': {
        'up': 570425449,
        'down': 771752045,
        'left': 637534314,
        'right': 671088747
    },
    'windows': {
        'up': 38,
        'down': 40,
        'left': 37,
        'right': 39
    }
}

def get_os(): 
    import platform
    if platform.system() == 'Darwin':
        return 'mac'
    else:
        return 'windows'

def get_up_keycode():
    return key_codes[get_os()]['up']

def get_down_keycode():
    return key_codes[get_os()]['down']

def get_left_keycode():
    return key_codes[get_os()]['left']

def get_right_keycode():
    return key_codes[get_os()]['right']
