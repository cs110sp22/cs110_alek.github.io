chores = [
    'Feed the dog',
    'Take out the trash',
    'Call Alex',
    'Study for test',
    'Go shopping',
    'Do the dishes'
]

# In the section below, prompt your user to ask them which chore they've just
# completed. Then remove that chore from the chores list:

print(chores)
num = int(input('What do you want to remove (int: 0, 1 ...)? '))
chores.pop(num)

print(chores)
num = int(input('What do you want to remove (int: 0, 1 ...)? '))
chores.pop(num)

print(chores)
num = int(input('What do you want to remove (int: 0, 1 ...)? '))
chores.pop(num)

print(chores)
