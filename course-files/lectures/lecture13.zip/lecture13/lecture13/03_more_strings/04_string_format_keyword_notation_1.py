# Using positional notation:
template = '{name} is {age} years old.'

print(template.format(name='Sally', age=20))  
print(template.format(name='Rafael', age=50))  
print(template.format(name='Dorcas', age=61))  
print(template.format(name='Krista', age=90))    