# Using positional notation:
template = '{0} is {1} years old.'

print(template.format('Sally', 20))  
print(template.format('Rafael', 50))  
print(template.format('Dorcas', 61))  
print(template.format('Krista', 90))    