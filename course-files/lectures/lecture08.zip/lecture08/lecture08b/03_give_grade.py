'''
Practice:
Write a function called give_grade that takes 1 
positional parameter —  a float called score that 
can range from 0 to 100 — and returns a letter grade 
(a string).

Assume:
90 - 100:	A
80 - 89:	B
70 - 79:	C
60 - 69:	D
< 60:		F

Proved that your function works by printing the 
results of several function calls to the screen...
'''
