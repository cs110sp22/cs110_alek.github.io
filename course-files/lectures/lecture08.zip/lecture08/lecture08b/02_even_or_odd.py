'''
Practice:
Write a function called even_or_odd that takes 1 
positional parameter —  an int called num — and 
returns a string that says either 'even' or 'odd'
Prove that your function works by printing the results 
of several function calls to the screen
'''